public class Podcast extends Conteudo {

    private String apresentador;
    private int numeroEpisodio;

    public Podcast(String titulo, int duracaoSegundos, String apresentador, int numeroEpisodio) {
        super(titulo, duracaoSegundos);

        setApresentador(apresentador);
        setNumeroEpisodio(numeroEpisodio);
    }

    public String getApresentador() {
        return apresentador;
    }

    public void setApresentador(String apresentador) {
        if (apresentador == null || apresentador.trim().isEmpty()) {
            throw new IllegalArgumentException("O apresentador não pode ser nulo ou vazio.");
        }

        this.apresentador = apresentador;
    }

    public int getNumeroEpisodio() {
        return numeroEpisodio;
    }

    public void setNumeroEpisodio(int numeroEpisodio) {
        if (numeroEpisodio < 1) {
            throw new IllegalArgumentException("O número do episódio deve ser maior que 0.");
        }

        this.numeroEpisodio = numeroEpisodio;
    }

    @Override
    public String getCreditos() {
        return super.getCreditos() + " - Episódio " + numeroEpisodio + " - " + apresentador;
    }
}
